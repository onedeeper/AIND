class Friend:

    #class variables  - common to all instances
    num_of_friends = 0
    add_pet_value = 1

    def __init__(self, location, profession, num_pets):
        #instance variables are unique to each instance
        self.location = location
        self.profession = profession
        self.num_pets = num_pets
        #self.loc_pet = location + '.' + str(num_pets)
        Friend.num_of_friends += 1

    @property
    def location_profession(self):
        return (self.location + '_' + self.profession)

    @location_profession.setter
    def location_profession(self, locprof):
        #print(locprof)
        location, profession = locprof.split('.')
        self.location = location
        self.profession = profession

    def add_pet(self):
        self.num_pets = self.num_pets + self.add_pet_value

    #we're creating the email like a method but with @property, it can be accessed like an attribute
    #@property
    def loc_pet(self):
        return (self.location + str(self.num_pets))

    @classmethod #altering the functionality of the method to use the class as the first variable
    def set_pet_add(cls, pet_amt):
        cls.add_pet_value = pet_amt

    #def __repr__(self):
    #    return("Friend('{}','{}','{}')".format(self.location, self.profession, self.num_pets))

    #def __str__(self):
    #    return('{}-{}'.format(self.location,self.profession))
    #alternative constructor
    @classmethod
    def from_string(cls,friend_string):
        location, occupation, pet = friend_string.split('-')
        return cls(location, occupation, pet)

    @staticmethod
    def is_workday(day):
        if day.weekday() == 5 or day.weekday() == 6:
            return(False)
        return True

#creating a bestfriend subclass
class Bestfriend(Friend):
    add_pet_value = 5
    #add additional information to the sublass than the parent class
    def __init__(self, location, profession, num_pets,spouse):
        #let our parent class handle the first, last and pay variables
        #by calling the parents init method
        #custominzing
        super().__init__(location,profession, num_pets)
        self.spouse = spouse


#A class is basically a blueprint for creating a new friend
#using a subclass which inherits variables and functions from the parent class
malinga = Bestfriend('London','doctor', 4,'vindhya')
viren = Bestfriend('Colombo','engineer', 1, 'None')

print(malinga)
#malinga.location_profesion = 'colombo.plumber'
#print(malinga.location, malinga.profession)

#get info about the inheritances
#print(help(Bestfriend))

#will tell us if object is an iSnstance of a class
#print(isinstance(malinga, Bestfriend))

#issubclass(A,B) tells us T/F if A is a subclass of B
#print(issubclass(Bestfriend,Friend))

#repr method returns a more readable output for debugging etc
